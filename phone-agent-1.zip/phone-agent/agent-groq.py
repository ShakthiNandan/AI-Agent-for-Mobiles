#!/usr/bin/env python3
"""agent-groq.py - phone agent using Groq cloud LLM + local phone_mcp.py.
Usage: python agent-groq.py "Open WhatsApp, go into the first chat, and send 'hi'"
Needs: pip install groq ; export GROQ_API_KEY=...
"""
import json, time, sys, os
import groq
from groq import Groq
from common import ts, MCPClient, has_focused_text_field, ScreenHistory, approx_tokens

MODEL = os.environ.get("GROQ_MODEL", "openai/gpt-oss-120b")
llm = Groq(api_key=os.environ["GROQ_API_KEY"], max_retries=1)


def to_openai_tools(mcp_tools):
    return [{"type": "function", "function": {
        "name": t["name"], "description": t["description"],
        "parameters": t["inputSchema"]}} for t in mcp_tools]


SYSTEM_PROMPT = """You are an autonomous phone-control agent. You get a goal and the \
current screen state (compact list of visible elements with tap coordinates). \
Call one tool per turn. After tap, launch_app, key_event and open_spotify_search the \
new screen state is shown automatically. type_text is blocked unless an EditText is \
visible in the last screen state. Prefer dedicated shortcut tools (e.g. \
open_spotify_search) over manual navigation. Use exact package names \
(Spotify: com.spotify.music, WhatsApp: com.whatsapp). \
To open a chat/list item, tap the middle of its row (name text or wide row), never the \
small round avatar at the far left (that only opens a photo preview). \
To type: first tap the EditText field; type_text is only allowed while an EditText is \
marked FOCUSED in the latest screen state. Then tap Send and confirm the message appears. \
Never reply DONE until the latest screen state visibly confirms the goal was achieved \
(e.g. playback controls showing the right track, message shown as sent). \
If not achieved, keep working. Final reply must start with "DONE:"."""

VERIFY_AFTER = {"tap", "launch_app", "key_event", "open_spotify_search"}


def chat(messages, tools):
    """LLM call with backoff for Groq's per-minute token limits (413/429)."""
    for attempt in range(5):
        try:
            return llm.chat.completions.create(model=MODEL, messages=messages, tools=tools)
        except groq.APIStatusError as e:
            if e.status_code in (413, 429) and attempt < 4:
                wait = 20 + 10 * attempt
                print(f"[{ts()}] rate limited ({e.status_code}); waiting {wait}s", file=sys.stderr)
                time.sleep(wait)
                continue
            raise


def run_agent(goal, max_steps=20):
    client = MCPClient()
    mcp_tools = client.list_tools()
    known = {t["name"] for t in mcp_tools}
    tools = to_openai_tools(mcp_tools)
    messages = [{"role": "system", "content": SYSTEM_PROMPT},
                {"role": "user", "content": f"Goal: {goal}"}]
    history = ScreenHistory()
    last_screen = None

    for step in range(1, max_steps + 1):
        print(f"\n[{ts()}] --- step {step} (~{approx_tokens(messages)} tokens in context) ---", file=sys.stderr)
        t0 = time.time()
        resp = chat(messages, tools)
        print(f"[{ts()}] (model {time.time()-t0:.2f}s)", file=sys.stderr)
        msg = resp.choices[0].message
        messages.append(msg.model_dump(exclude_none=True))

        if not msg.tool_calls:
            print(f"[{ts()}] Model: {msg.content}", file=sys.stderr)
            if msg.content and msg.content.strip().upper().startswith("DONE"):
                client.close()
                return msg.content
            messages.append({"role": "user", "content":
                             "Call a tool, or reply 'DONE: <summary>' if verified complete."})
            continue

        for tc in msg.tool_calls:
            name = tc.function.name
            try:
                args = json.loads(tc.function.arguments or "{}")
            except json.JSONDecodeError:
                args = {}
            print(f"[{ts()}] Calling {name}({args})", file=sys.stderr)

            has_screen, action_part = False, ""
            if name not in known:
                result = f"ERROR: unknown tool '{name}'. Valid tools: {sorted(known)}"
            elif name == "type_text" and not has_focused_text_field(last_screen):
                result = ("BLOCKED: no focused text field. Tap the EditText first, then "
                          "check that it is marked FOCUSED in the screen state before typing.")
                print(f"[{ts()}] BLOCKED type_text (no FOCUSED EditText)", file=sys.stderr)
            elif name == "get_screen_state":
                result = client.call_tool(name, args)
                last_screen, has_screen = result, True
            else:
                action_part = client.call_tool(name, args)
                result = action_part
                if name in VERIFY_AFTER:
                    time.sleep(1.0)
                    verify = client.call_tool("get_screen_state", {})
                    result = f"{action_part}\n\n[Screen after {name}:]\n{verify}"
                    last_screen, has_screen = verify, True

            history.append_tool(messages, {"role": "tool", "tool_call_id": tc.id, "content": result},
                                has_screen=has_screen, action_part=action_part)

    client.close()
    return "STOPPED: max steps reached."


if __name__ == "__main__":
    goal = sys.argv[1] if len(sys.argv) > 1 else input("Goal: ")
    start = time.time()
    out = run_agent(goal)
    print(f"\n=== RESULT ({time.time()-start:.1f}s) ===\n{out}")
